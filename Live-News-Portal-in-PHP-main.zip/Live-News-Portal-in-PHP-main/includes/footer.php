<!--  Author Name: MH RONY.
                        GigHub Link: https://github.com/dev-mhrony
                        Facebook Link:https://www.facebook.com/dev.mhrony
                        Youtube Link: https://www.youtube.com/channel/UChYhUxkwDNialcxj-OFRcDw
                        for any PHP, Laravel, Python, Dart, Flutter work contact me at developer.mhrony@gmail.com  
                        Visit My Website : developerrony.com -->
<div class="footer-area pt-3 bg-white mb-5">
    <div class="container-fluid">
        <br>

        <div class="row">


            <div class="col">
                <a class="navbar-brand" href="index.php"><img src="images/logo.png" height="65"></a>
                <ul class="float-left list-unstyled ">

                    <li class="mb-2">Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum id vitae fugiat, </li>


                </ul>
            </div>
            <div class="col">
                <ul class="float-left list-unstyled ">
                    <li class="mb-2"><a class="text-dark" href="#">Healthy Living</a></li>
                    <li class="mb-2"><a class="text-dark" href="#">Medical Research</a></li>
                    <li class="mb-2"><a class="text-dark" href="#">Children’s Health</a></li>

                </ul>
            </div>
            <div class="col">
                <ul class="float-left list-unstyled ">
                    <li class="mb-2"><a href="#" class="text-dark">Real Estate</a></li>
                    <li class="mb-2"><a href="#" class="text-dark">Commercial</a></li>
                    <li class="mb-2"><a href="#" class="text-dark">Find A Home</a></li>

                </ul>
            </div>
            <div class="col">
                <ul class="float-left list-unstyled ">
                    <li class="mb-2"><a href="#" class="text-dark">U.S.</a></li>
                    <li class="mb-2"><a href="#" class="text-dark">Politics</a></li>
                    <li class="mb-2"><a href="#" class="text-dark">N.Y.</a></li>

                </ul>
            </div>


        </div>

        <div style=" padding: 10px; margin-top: 20px;
    display: flex;
    justify-content: space-around;
    
    align-items: center;">
            <p style="text-align: center; "> CopyRight by <a href="https://www.youtube.com/@codecampbdofficial">Code Camp BD</a> Design and Developer <a href="https://developerrony.com">MH RONY</a> All Resalve
                <?php echo "20".date("y"); ?></p>
        </div>
    </div>
</div>
<!--  Author Name: MH RONY.
                        GigHub Link: https://github.com/dev-mhrony
                        Facebook Link:https://www.facebook.com/dev.mhrony
                        Youtube Link: https://www.youtube.com/channel/UChYhUxkwDNialcxj-OFRcDw
                        for any PHP, Laravel, Python, Dart, Flutter work contact me at developer.mhrony@gmail.com  
                        Visit My Website : developerrony.com -->
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<script type="text/javascript">
function googleTranslateElementInit() {
    new google.translate.TranslateElement({
        pageLanguage: 'en'
    }, 'google_translate_element');
}
</script>
<!--  Author Name: MH RONY.
                        GigHub Link: https://github.com/dev-mhrony
                        Facebook Link:https://www.facebook.com/dev.mhrony
                        Youtube Link: https://www.youtube.com/channel/UChYhUxkwDNialcxj-OFRcDw
                        for any PHP, Laravel, Python, Dart, Flutter work contact me at developer.mhrony@gmail.com  
                        Visit My Website : developerrony.com -->
<style>
.goog-logo-link {
    display: none !important;
}

.goog-te-gadget {
    color: transparent;
}

.goog-te-gadget .goog-te-combo {
    margin: 0px 0;
    padding: 8px;
    color: #000;
    background: #eeee;
}

#google_translate_element {
    padding-top: 13px;
    position: absolute;
    top: 7px;
    right: 100px;
}
</style>
<!--  Author Name: MH RONY.
                        GigHub Link: https://github.com/dev-mhrony
                        Facebook Link:https://www.facebook.com/dev.mhrony
                        Youtube Link: https://www.youtube.com/channel/UChYhUxkwDNialcxj-OFRcDw
                        for any PHP, Laravel, Python, Dart, Flutter work contact me at developer.mhrony@gmail.com  
                        Visit My Website : developerrony.com -->